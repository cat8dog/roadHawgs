// Die numbers
let number;

let one;
let two;
let three;
let four;
let five;
let six;

function preload() {
  one = loadImage('P1-assets/1.png');
  two = loadImage('P1-assets/2.png');
  three = loadImage('P1-assets/3.png');
  four = loadImage('P1-assets/4.png');
  five = loadImage('P1-assets/5.png');
  six = loadImage('P1-assets/6.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  setShakeThreshold(40);
}

function draw() {
  //background('#7fb85c');
  background(50, 50, 50);
  
  imageMode(CENTER);
  if (number == 1) {
    image(one, windowWidth / 2, windowHeight / 2, 1200, 1200)
  }
  if (number == 2) {
    image(two, windowWidth / 2, windowHeight / 2, 1200, 1200)
  }
  if (number == 3) {
    image(three, windowWidth / 2, windowHeight / 2, 1200, 1200)
  }
  if (number == 4) {
    image(four, windowWidth / 2, windowHeight / 2, 1200, 1200)
  }
  if (number == 5) {
    image(five, windowWidth / 2, windowHeight / 2, 1200, 1200)
  }
  if (number == 6) {
    image(six, windowWidth / 2, windowHeight / 2, 1200, 1200)
  }
}

// Toss function:

function deviceShaken() {
  let dice = [1, 2, 3, 4, 5, 6]
  number =random(dice);

}