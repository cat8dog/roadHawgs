// We referenced Shiffman's code for the swipe feature in our blog post

//roadpieces toggle variable
let n = 0;

//blockers toggle variable
let m = 0;

//reliefs toggle variables
let p = 0;

let r = 17;
let g = 15;
let b = 16;

//variable to change tabs to access different tool sets
//roadpieces: t=2,  blockers: t=1,  reliefs: t=3
let t = 2;

//variables for images
let dynamite;
let river;
let roadblock_down;

let bribe;
let bridge;
let train;

let sw = 1;

function preload() {
  dynamite = loadImage('Assets/dynamite_pink.png');
  river = loadImage('Assets/river_pink.png');
  roadblock_down = loadImage('Assets/roadblock_down_pink.png');
  train = loadImage('Assets/train_pink.png');

  bribe = loadImage('Assets/bribe_pink.png');
  bridge = loadImage('Assets/bridge_pink.png');
  
}



function setup() {

  createCanvas(windowWidth, windowHeight);

  // set options to prevent default behaviors for swipe, pinch, etc
  var options = {
    preventDefault: true
  };

  // document.body registers gestures anywhere on the page
  var hammer = new Hammer(document.body, options);
  hammer.get('swipe').set({
    direction: Hammer.DIRECTION_ALL
  });

  hammer.on("swipe", swiped);
}


function draw() {
  background(r, g, b);
  imageMode(CENTER);

  // (default centre)  
  if (t == 2) {
    roadpieces(150, 400);
  }

  // (swipe right)
  if (t == 1) {
    blockers();
  }

  // (swipe left)
  if (t == 3) {
    reliefs();
  }
}

// Shiffman's swipe code: 

function swiped(event) {
  console.log(event);
  if (event.direction == 4 && t < 3) {
    //msg = "you swiped right";
    t = t + 1
  } else if (event.direction == 8) {
    //msg = "you swiped up";
  } else if (event.direction == 16) {
    //msg = "you swiped down";
  } else if (event.direction == 2 && t > 1) {
    //msg = "you swiped left";
    t = t - 1
  }
}


// touch toggle that iterates through the 'tools'
function touchStarted() {
  if (t == 1) {
    //blockers
    m++;
  }
  if (t == 2) {
    //roadpieces
    n++;
  }
  if (t == 3) {
    //reliefs
    p++
  }

  return false;
}



//roadpieces
function roadpieces(sw, curve) {

  rectMode(CENTER);
  stroke(237, 50, 120);
  strokeWeight(sw);
  noFill();


  if (n == 5) {
    n = 0
  }

  //vertical line
  if (n == 0) {
    rectMode(CENTER);
    stroke(237, 50, 120);
    strokeWeight(sw);
    noFill();
    //pink line
    line(windowWidth / 2, 0, windowWidth / 2, windowHeight);
    //dahsed line
    stroke(10, 10, 10);
    strokeWeight(12);
    drawingContext.setLineDash([40, 50]);
    line(windowWidth / 2, 0, windowWidth / 2, windowHeight);
    drawingContext.setLineDash([100, 0]);
  }

  //horizontal line
  if (n == 1) {
    rectMode(CENTER);
    stroke(237, 50, 120);
    strokeWeight(sw);
    noFill();
    //pink line
    line(0, windowHeight / 2, windowWidth, windowHeight / 2);
    //dashed line
    stroke(10, 10, 10);
    strokeWeight(12);
    drawingContext.setLineDash([40, 50]);
    line(0, windowHeight / 2, windowWidth, windowHeight / 2);
    drawingContext.setLineDash([100, 0]);
  }

  //turn right
  if (n == 2) {
    rectMode(CENTER);
    stroke(237, 50, 120);
    strokeWeight(sw);
    noFill();
    drawingContext.setLineDash([0]);
    rect(windowWidth, 0, windowWidth, windowHeight, curve);
    //dashed line
    push();
    stroke(10, 10, 10);
    strokeWeight(12);
    drawingContext.setLineDash([40, 50]);
    rect(windowWidth, 0, windowWidth, windowHeight, curve);
    pop();
  }


  //turn left
  if (n == 3) {
    rectMode(CENTER);
    stroke(237, 50, 120);
    strokeWeight(sw);
    noFill();
    drawingContext.setLineDash([0]);
    rect(0, 0, windowWidth, windowHeight, curve);
    //dashed line
    push();
    stroke(10, 10, 10);
    strokeWeight(12);
    drawingContext.setLineDash([40, 50]);
    rect(0, 0, windowWidth, windowHeight, curve);
    pop();
  }

  //u-turn
  if (n == 4) {
    drawingContext.setLineDash([0]);
    rect(0, windowHeight / 2, windowWidth * 1.3, windowHeight / 2, curve * 3);
    //dashed line
    push();
    stroke(10, 10, 10);
    strokeWeight(12);
    drawingContext.setLineDash([40, 50]);
    rect(0, windowHeight / 2, windowWidth * 1.3, windowHeight / 2, curve * 3);
    pop();
  }
}



//blockers
function blockers() {
  rectMode(CENTER);
  noStroke();
  fill('#ff6600');

  if (m == 4) {
    m = 0
  }

  //dynamite
  if (m == 0) {
    image(dynamite, windowWidth / 2, windowHeight / 2, 966 / 2.2, 764 / 2.2);
  }

  //river
  if (m == 1) {
    image(river, windowWidth / 2, windowHeight / 2, (652 / 1931) * windowHeight, windowHeight);
  }

  //roadblock_allroads
  if (m == 2) {
    image(roadblock_down, windowWidth / 2, windowHeight / 2, 692 / 1.8, 592 / 1.8);
  }
  
  //train
  if (m == 3) {
    image(train, windowWidth /2, windowHeight / 2, (1104 / 1920) * windowHeight, windowHeight);
      }
}



//reliefs
function reliefs() {
  rectMode(CENTER);
  noStroke();
  fill('#ff0000');

  if (p == 2) {
    p = 0
  }

  //option1
  if (p == 0) {
    image(bribe, windowWidth / 2, windowHeight / 2, 1080 / 2.5, 631 / 2.5);
  }

  //option2
  if (p == 1) {
    image(bridge, windowWidth / 2, windowHeight / 2, (456 / 1920) * windowHeight, windowHeight);
  }
}